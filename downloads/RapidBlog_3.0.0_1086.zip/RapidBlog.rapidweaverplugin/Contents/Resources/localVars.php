<?php

/*
 *
 * Variables that change from within plugin 
 * Variables delimited with { - and - } will get replaced at runtime
 */

$phpBlogOrder='{-rapidblog.phpBlogOrder-}';

$categories=""; // Categories start out empty

// What kind of get should we do for each kind of page (full, or summary )

$bloggerGetMainPage="{-rapidblog.bloggerGetMainPage-}" ; // "/default";
$bloggerGetCategoryPage="{-rapidblog.bloggerGetCategoryPage-}";
$bloggerGetArchivePage="{-rapidblog.bloggerGetArchivePage-}";
$bloggerGetType=$bloggerGetMainPage ; // default type is the main page type
$bloggerURL="{-blogfeed-}"; 


// Text that is presented to the user (controlled via setup)

$readMoreText="{-rapidblog.readMoreText.stringByEscapingHTMLEntities-}"; // What to say when in summary view and  a 'read more' occurs
$commentIdentifier="{-rapidblog.commentIdentifier.stringByEscapingHTMLEntities-}";
$commentIntroduction="{-rapidblog.commentIntroduction.stringByEscapingHTMLEntities-}";
$commentHideString="{-rapidblog.commentHideString.stringByEscapingHTMLEntities-}";
$commentShowString="{-rapidblog.commentShowString.stringByEscapingHTMLEntities-}";
$permalinkTitle="{-rapidblog.permalinkTitle.stringByEscapingHTMLEntities-}";
$rssLinkName="{-rapidblog.rssLinkName.stringByEscapingHTMLEntities-}";
$blogCommentService={-rapidblog.blogCommentService-}; // 0=blogger, 1=Haloscan
$haloscanUsername="{-rapidblog.haloscanUsername-}";
$disqusShortName="{-rapidblog.disqusShortName-}"; // disqus short name for disqus comments


// Controls how many items are displayed
$howFarBackToView="{-rapidblog.showPostsFromLastNDays-}";//
$howFarBackToViewEnabled={-rapidblog.showPostsFromLastDays.intValue-}?false:true;// if enabled then we include the date in the search
$maxNumberPostsToShow="{-rapidblog.maxNumberPostsToShow-}";
$filesFolder="{-filesfoldername-}";

// Things to show/hide

$showPermalinks={-rapidblog.enablePermalinks.intValue-};
$permalinkType={-rapidblog.permalinkTypeTag.intValue-}; // 0=seperate, 1= in title
$showRSS={-rapidblog.rssEnabled.intValue-};
$rssFileName="{-rapidblog.rssFileName-}";
$showAuthor={-rapidblog.showAuthor.intValue-};
$showNumberOfComments={-rapidblog.showNumberOfComments.intValue-};
$reverseCommentEntries={-rapidblog.reverseCommentEntries.intValue-};
$bloggerCommentsInPopup={-rapidblog.bloggerCommentsInPopup.intValue-};
$commentsEnabled={-rapidblog.commentsEnabled.intValue-};
$expandCommentsInMainPage={-rapidblog.expandCommentsInMainPage.intValue-};
$expandCommentsInPermalinkPage={-rapidblog.expandCommentsInPermalinkPage.intValue-};
$expandCommentsInCategoryPage={-rapidblog.expandCommentsInCategoryPage.intValue-};
$showArchives={-rapidblog.showArchives.intValue-};
$archivesDropdown={-rapidblog.archivesDropdown.intValue-};
$archivesDropdownTitle="{-rapidblog.archivesDropdownTitle-}";
$showCategories={-rapidblog.showCategories.intValue-};

// Date formats

$dateFormat="{-rapidblog.phpDateFormat-}";
$timeFormat="{-rapidblog.phpTimeFormat-}";
$dateTimeSeperator="{-rapidblog.dateTimeSeperator-}";
$dateLocalizeConvert=Array({-dateLocalizeConvertArray-});


// Misc 
$tempFilesDirectory="{-rapidblog.localParams.path-}"; // used only for preview mode
$exportMode="{-mode-}"; // should be 'preview' or 'export' or 'publish'
$categoriesArray=Array({-categoriesPHPArray-});
$gravatarArray=Array({-gravatarPHPArray-});
$gravatarSize={-rapidblog.gravatarSize.intValue-};
$ajaxy={-rapidblog.ajaxy.intValue-}; // Determine if we should render some effects in a ajaxy fashion

				
$urlToThisPage="{-rapidblog.absoluteURLToThisPage-}";
	
// $blogCreationDate="{-rapidblog.blogCreationDate-}";
$archiveFormat="{-rapidblog.phpArchiveFormat-}";
$archiveOrdering={-rapidblog.archiveOrdering.intValue-};
$pageCharSet="{-pagecharset-}";

// interComments


$interHTMLText='{-rapidblog.interHTMLText.stringByEscapingSingleQuotes-}';
$interEvaluatePHPCode={-rapidblog.interEvaluatePHPCode-}; // true if we should pass the inter text through eval
$interTextAfterFirst={-rapidblog.interTextAfterFirst.intValue-}-1; // php is zero based but users start with one so offset it
$interTextRepeat={-rapidblog.interTextRepeat.intValue-};

// Older Posts
$olderPostsString="{-rapidblog.olderPostsString-}";
$olderPostsEnabled={-rapidblog.olderPostsEnabled.intValue-};

//
$random="{-random-}"; // believe it or not, this is just to guarantee you never get 'nothing to upload'


?>

