<?php


/*
 *                          
 * Variable's that change withing 
 * Plugin 
 */

/* For PHP 5.1 (& Snow Leopard)  */
if (function_exists('date_default_timezone_set'))
	@date_default_timezone_set(date_default_timezone_get());
	
if ("{-mode-}"=="preview")
	set_include_path(get_include_path() . PATH_SEPARATOR . "{-rapidblog.localParams.path-}"  ); // for preview only
	
set_include_path(get_include_path() . PATH_SEPARATOR . "{-filesfoldername-}");
	
if ("{-mode-}" != "preview")
	error_reporting(E_ERROR); // supress notices & warning

require_once("{-filesfoldername-}/localVars.php");
if (!class_exists("PEAR"))
    require_once("{-filesfoldername-}/LHPEAR.php");
require_once("{-filesfoldername-}/Socketrb.php");
require_once("{-filesfoldername-}/URLrb.php");
require_once("{-filesfoldername-}/xmlrb.php");
require_once("{-filesfoldername-}/Requestrb.php");
require_once("{-filesfoldername-}/rapidBlogHelpers.php"); 


/*************************************************************/
// Figure out what I am

$thisFile=basename(__FILE__); 
// End of figure out who I am


@ini_set('magic_quotes_runtime',0); // turn off 'magic quotes' which will otherwise break RapidBlog


	/* As appropriate render sidebar */
	
	renderCategoriesInSidebar();


	/* As apprporiate render archives */
	
	renderArchives();
/* End of blog archives */



if ($showRSS) {
	print 	"<div id='blog-rss-feeds'>";
	print 	"<a class='blog-rss-link' href='$filesFolder/$rssFileName' rel='alternate' type='application/rss+xml' title='RSS Feed'>";
	print	 	utf2html($rssLinkName);
	print 	"</a>";
	print 	"<br />";
	print "</div>";
}

?>